use std::process::Command;
use std::str;

pub fn ethix_guard(payload: &str, key: &str) -> Vec<String> {
    let cli_path = if cfg!(target_os = "windows") {
        "../bin/ethixion_cli.exe"
    } else if cfg!(target_os = "macos") {
        "../bin/ethixion_cli_mac"
    } else {
        "../bin/ethixion_cli"
    };

    let output = Command::new(cli_path)
        .args(&["--payload", payload, "--key", key])
        .output();

    match output {
        Ok(out) => {
            if !out.status.success() {
                return vec![];
            }
            let stdout = str::from_utf8(&out.stdout).unwrap_or("");
            if stdout.contains("Decrypted data:") {
                let array_str = stdout
                    .replace("Decrypted data:", "")
                    .replace(&['[', ']'][..], "")
                    .replace("\"", "");
                return array_str
                    .split(',')
                    .map(|s| s.trim().to_string())
                    .filter(|s| !s.is_empty())
                    .collect();
            }
            vec![]
        }
        Err(_) => vec![],
    }
}
