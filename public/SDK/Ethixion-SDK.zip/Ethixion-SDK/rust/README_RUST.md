
---

## Rust README (`README_RUST.md`)

```markdown
# Ethixion SDK for Rust

This Rust SDK allows you to decrypt data encrypted via **Ethixion Gateway Service** using the `ethixion_cli` binary. It returns a `Vec<String>` directly.

---

## Installation

1. Include the `ethixion_sdk` crate in your project.
2. Place the `ethixion_cli` binary in `../bin/` relative to your project.

---

## Usage

```rust
use ethixion_sdk::ethix_guard;

fn main() {
    let payload = "<BASE64_HASHED_PAYLOAD>";
    let key = "<AES_KEY>";

    let result = ethix_guard(payload, key);
    println!("{:?}", result); // Output: ["DATA1", "DATA2"]
}
