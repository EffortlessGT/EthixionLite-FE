# Ethixion SDK

## Overview

The **Ethixion SDK** provides developers with a simple, universal way to decrypt data securely sent via the **Ethixion Gateway Service**.  
This SDK handles:

- Base64 decoding
- AES-GCM decryption
- Conversion of payload into a ready-to-use array

It is designed to work with multiple web application languages including **Python, Node.js, PHP, and Java**, allowing developers to quickly integrate Ethixion services into their applications without dealing with low-level cryptography.

---

## Features

- Easy integration: Call a single function (`decrypt`) with the encrypted payload and key.
- Language-agnostic: SDK includes ready-to-use templates for popular web languages.
- Secure: Uses AES-256-GCM encryption for data confidentiality.
- Minimal setup: No additional dependencies required besides the SDK and CLI binary.

---

## Developer

This SDK is developed by **Ganesh Telore**, a software enthusiast and security-focused developer dedicated to building secure and simple solutions for web applications.

---

## Provided By

**Ethixion Gateway Service** – A secure service for transmitting and verifying sensitive data between clients and backend systems.

---

## Installation

1. Download the SDK package for your language.
2. Place the `bin/` folder and the language-specific folder (`python/`, `nodejs/`, `php/`, `java/`) in your project directory.
3. Ensure the CLI binary has execution permissions:
   ```bash
   chmod +x bin/ethixion_cli

