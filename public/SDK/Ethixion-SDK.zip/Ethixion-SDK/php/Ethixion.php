<?php
class Ethixion {
    private static function getCliPath() {
        $os = PHP_OS_FAMILY;
        if ($os === "Windows") return __DIR__ . '/../bin/ethixion_cli.exe';
        if ($os === "Darwin") return __DIR__ . '/../bin/ethixion_cli_mac';
        return __DIR__ . '/../bin/ethixion_cli';
    }

    public static function decrypt($payload, $key) {
        $cli = self::getCliPath();
        $output = [];
        $return_var = 0;
        exec("$cli --payload $payload --key $key", $output, $return_var);
        $output_str = implode("\n", $output);
        if (strpos($output_str, "Decrypted data:") !== false) {
            $arr_str = str_replace("Decrypted data:", "", $output_str);
            return eval("return $arr_str;");
        }
        return [];
    }
}
