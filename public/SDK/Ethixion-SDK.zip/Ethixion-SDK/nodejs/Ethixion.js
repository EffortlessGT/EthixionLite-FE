const { execFileSync } = require("child_process");
const path = require("path");
const os = require("os");

function getCliPath() {
    const platform = os.platform();
    if (platform === "win32") return path.join(__dirname, "../bin/ethixion_cli.exe");
    if (platform === "darwin") return path.join(__dirname, "../bin/ethixion_cli_mac");
    return path.join(__dirname, "../bin/ethixion_cli");
}

function decrypt(payload, key) {
    const cliPath = getCliPath();
    try {
        const output = execFileSync(cliPath, ["--payload", payload, "--key", key], { encoding: "utf-8" });
        if (output.includes("Decrypted data:")) {
            return JSON.parse(output.replace("Decrypted data:", "").trim().replace(/'/g, '"'));
        }
        return [];
    } catch (err) {
        return [];
    }
}

module.exports = { decrypt };
