# Ethixion SDK for Node.js

This Node.js SDK allows you to decrypt data encrypted via **Ethixion Gateway Service** using the `ethixion_cli` binary. It returns an array of strings directly.

---

## Installation

1. Place the `ethixion_cli` binary in `../bin/` relative to your project.
2. Copy `ethixion.js` into your project folder.

---

## Usage

```javascript
const ethixion = require('./ethixion');

const payload = "<BASE64_HASHED_PAYLOAD>";
const key = "<AES_KEY>";

const result = ethixion.decrypt(payload, key);
console.log(result); // Output: ["Ganesh Telore", "Prashant Telore"]
