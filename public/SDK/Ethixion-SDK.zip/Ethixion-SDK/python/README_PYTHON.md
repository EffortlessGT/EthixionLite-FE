# Ethixion SDK for Python

This Python SDK allows you to decrypt data encrypted via **Ethixion Gateway Service**. It uses the `ethixion_cli` binary internally, so you do not need to implement any decryption logic. Just import the SDK and call the function.

---

## Installation

1. Download the SDK folder and place it in your project.
2. Ensure the CLI binary (`ethixion_cli`, `ethixion_cli.exe`, or `ethixion_cli_mac`) is in `../bin/` relative to your project.

---

## Usage

```python
from ethixion import ethix_guard

payload = "<BASE64_HASHED_PAYLOAD>"
key = "<AES_KEY>"

# Decrypt the payload
result = ethix_guard(payload, key)
print(result)  # // Output: ["DATA1", "DATA2"]
