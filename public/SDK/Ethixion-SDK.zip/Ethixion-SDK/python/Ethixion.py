import subprocess
import sys
import os
import platform


def _get_cli_path():
    system = platform.system()
    if system == "Windows":
        return os.path.join(os.path.dirname(__file__), "../bin/ethixion_cli.exe")
    elif system == "Darwin":
        return os.path.join(os.path.dirname(__file__), "../bin/ethixion_cli_mac")
    else:
        return os.path.join(os.path.dirname(__file__), "../bin/ethixion_cli")

def decrypt(payload: str, key: str) -> list:
    cli_path = _get_cli_path()
    try:
        result = subprocess.run(
            [cli_path, "--payload", payload, "--key", key],
            capture_output=True,
            text=True
        )
        output = result.stdout.strip()
        if "Decrypted data:" in output:
            return eval(output.replace("Decrypted data:", "").strip())
        return []
    except Exception:
        return []
