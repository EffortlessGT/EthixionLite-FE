import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.List;

public class Ethixion {
    private static String getCliPath() {
        String os = System.getProperty("os.name").toLowerCase();
        if (os.contains("win"))
            return "../bin/ethixion_cli.exe";
        if (os.contains("mac"))
            return "../bin/ethixion_cli_mac";
        return "../bin/ethixion_cli";
    }

    public static List<String> decrypt(String payload, String key) {
        String cli = getCliPath();
        try {
            ProcessBuilder pb = new ProcessBuilder(cli, "--payload", payload, "--key", key);
            Process process = pb.start();
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null)
                sb.append(line);
            String output = sb.toString();
            if (output.contains("Decrypted data:")) {
                String arrayStr = output.replace("Decrypted data:", "").replaceAll("\\[|\\]", "").replaceAll("\"", "");
                return Arrays.asList(arrayStr.split(",\\s*"));
            }
        } catch (Exception e) {
            return Arrays.asList();
        }
        return Arrays.asList();
    }
}
