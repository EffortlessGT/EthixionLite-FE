
---

## Java README (`README_JAVA.md`)

```markdown
# Ethixion SDK for Java

This Java SDK allows you to decrypt data encrypted via **Ethixion Gateway Service** using the `ethixion_cli` binary.

---

## Usage

```java
import java.util.List;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        String payload = "<BASE64_HASHED_PAYLOAD>";
        String key = "<AES_KEY>";

        List<String> result = Ethixion.decrypt(payload, key);
        System.out.println(result); // Output: ["DATA1", "DATA2"]
    }
}
