package ethix_cli

import (
	"encoding/base64"
	"encoding/json"
	"errors"

	"github.com/aead/cipher/aesgcm"
)

type DecodedPayload struct {
	Ciphertext string `json:"ciphertext"`
	Nonce      string `json:"nonce"`
}

func EthixGuard(hashedPayload string, keyB64 string) ([]string, error) {

	payloadBytes, err := base64.StdEncoding.DecodeString(hashedPayload)
	if err != nil {
		return nil, errors.New("invalid Base64 payload")
	}

	payloadStr := string(payloadBytes)

	var decoded DecodedPayload
	if err := json.Unmarshal([]byte(payloadStr), &decoded); err != nil {
		return nil, errors.New("invalid JSON payload")
	}

	keyBytes, err := base64.StdEncoding.DecodeString(keyB64)
	if err != nil || len(keyBytes) != 32 {
		return nil, errors.New("invalid AES key, must be 32 bytes")
	}

	ciphertextBytes, err := base64.StdEncoding.DecodeString(decoded.Ciphertext)
	if err != nil {
		return nil, errors.New("invalid ciphertext")
	}

	nonceBytes, err := base64.StdEncoding.DecodeString(decoded.Nonce)
	if err != nil || len(nonceBytes) != 12 {
		return nil, errors.New("invalid nonce")
	}

	plaintext, err := aesgcm.Decrypt(keyBytes, nonceBytes, ciphertextBytes, nil)
	if err != nil {
		return nil, errors.New("decryption failed")
	}

	var result []string
	if err := json.Unmarshal(plaintext, &result); err != nil {
		return nil, errors.New("failed to parse decrypted data")
	}

	return result, nil
}
