
---

## Go README (`README_GO.md`)

```markdown
# Ethixion SDK for Go

This Go SDK allows you to decrypt data encrypted via **Ethixion Gateway Service** using the `ethixion_cli` binary.

---

## Installation

1. Place `ethixion_cli` binary in `../bin/` relative to your project.
2. Place `ethixion.go` (SDK file) in your project and import it.

---

## Usage

```go
package main

import (
    "fmt"
    "ethixion_sdk"
)

func main() {
    payload := "<BASE64_HASHED_PAYLOAD>"
    key := "<AES_KEY>"

    result := ethixion_sdk.EthixGuard(payload, key)
    fmt.Println(result) // Output: ["DATA1", "DATA2"]
}
